__version__ = '0.0.17'
from .rationals import Rational
