"""
This file imports code into the rational.mxnet package
"""
from .rationals import Rational
