"""
This file imports content into the torch.tests directory, making this a Python package.
E.g.: Only that way can Rational be imported 'directly' in the test files
"""
from ..rationals import Rational
