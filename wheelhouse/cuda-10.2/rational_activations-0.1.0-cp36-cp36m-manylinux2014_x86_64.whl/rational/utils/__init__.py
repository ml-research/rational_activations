from .utils import fit_rational_to_base_function, find_closest_equivalent
from .find_init_weights import find_weights
